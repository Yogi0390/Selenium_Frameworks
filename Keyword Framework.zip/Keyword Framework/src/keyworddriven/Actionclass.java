package keyworddriven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utilities.Constants;

public class Actionclass {
	public static WebDriver driver=null;

	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\yogen41\\Documents\\Selenium\\Drivers\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	public void navigate() {
	//	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.facebook.com");
	}

	public void enterEmail() {
		driver.findElement(By.id("email")).sendKeys(Constants.email);
	
	}

	public void enterPassword() {
		driver.findElement(By.id("password")).sendKeys(Constants.password);
	}

	public void clickLogin() {
		driver.findElement(By.xpath("//button[@name='login']")).click();
	}

}
