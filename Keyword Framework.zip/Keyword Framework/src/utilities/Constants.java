package utilities;

public class Constants {
	//public static final String URL = "https://www.facebook.com";
	public static final String filePath = "C:\\Users\\yogen41\\Documents\\Framework\\exceldata.xlsx";
	public static final String excelData = "exceldata.xlsx";
	public static final String email = "yogeshwari@gmail.com";
	public static final String password = "yogi@123";
}
