package executionengine;

import excelutility.Readexcelsheet;
import keyworddriven.Actionclass;

public class ExecutionTest {

	public static void main(String[] args) {
		Readexcelsheet rs = new Readexcelsheet();
		rs.DemoFile(4);
		Actionclass k = new Actionclass();
		k.openBrowser();
		k.navigate();
		k.enterEmail();
		k.enterPassword();
		k.clickLogin();
		System.out.println("Test executed successfully");
	}

}
