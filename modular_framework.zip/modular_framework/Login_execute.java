package modular_framework;    

import org.openqa.selenium.WebDriver;

public class Login_execute {
	public static void execute(WebDriver driver)
	{
		way2smslogin.txt_mobileno(driver).sendKeys("9686924354");
		way2smslogin.txt_password(driver).sendKeys("Pass@123");
		way2smslogin.txt_login(driver).click();
	}

	
}
