package modular_framework;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class way2smslogin {

	static WebElement element = null;

	public static WebElement txt_mobileno(WebDriver driver) {
		element = driver.findElement(By.id("mobileNo"));
		return element;
	}

	public static WebElement txt_password(WebDriver driver) {
		element = driver.findElement(By.id("password"));
		return element;
	}
	public static WebElement txt_login(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"loginform\"]/div[2]/div[2]/button"));
		return element;		
	}
		
}
